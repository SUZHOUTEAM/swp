/*
Navicat MySQL Data Transfer

Source Server         : swp
Source Server Version : 50518
Source Host           : rm-bp1d2e125t78314n3o.mysql.rds.aliyuncs.com:3306
Source Database       : yifei_db

Target Server Type    : MYSQL
Target Server Version : 50518
File Encoding         : 65001

Date: 2017-02-22 14:59:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for waste_type
-- ----------------------------
DROP TABLE IF EXISTS `waste_type`;
CREATE TABLE `waste_type` (
  `id` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `status` char(1) NOT NULL COMMENT '状态(0未启用、1启用)',
  `create_by` varchar(50) NOT NULL,
  `create_time` datetime NOT NULL,
  `edit_by` varchar(50) NOT NULL,
  `edit_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of waste_type
-- ----------------------------
INSERT INTO `waste_type` VALUES ('9101b2aaab314c4f813681151495d29a', 'HW01', '医疗废物', '1', 'system', '2016-06-23 16:09:02', 'system', '2016-06-23 16:09:02');
INSERT INTO `waste_type` VALUES ('af8a520353ae4074b0e0d3a1a65d2f89', 'HW02', '医药废物', '1', 'system', '2016-06-23 16:09:41', '1786843232307200', '2016-08-10 15:52:50');
INSERT INTO `waste_type` VALUES ('6688398f884e49feb50ca3c2a33ae43f', 'HW03', '废药物、 药品', '1', 'system', '2016-06-23 16:10:00', 'system', '2016-06-23 16:10:00');
INSERT INTO `waste_type` VALUES ('856f95b9e1b749528532d2b6a2699ab4', 'HW04', '农药废物', '1', 'system', '2016-06-23 16:50:49', 'system', '2016-06-23 16:50:49');
INSERT INTO `waste_type` VALUES ('0f5092f75e7a40d5ab7dbbed1f72e0e4', 'HW05', '木材防腐剂废物', '1', 'system', '2016-06-23 16:51:07', 'system', '2016-06-23 16:51:07');
INSERT INTO `waste_type` VALUES ('f82b97de9a9142a5a18c6d27939e958b', 'HW06', '废有机溶剂与含有机溶剂废物', '1', 'system', '2016-06-23 16:51:29', 'system', '2016-06-23 16:51:29');
INSERT INTO `waste_type` VALUES ('afd5a07100c946038efd96e8b7b41ddd', 'HW07', '热处理含氰废物', '1', 'system', '2016-06-23 16:51:43', 'system', '2016-06-23 16:51:43');
INSERT INTO `waste_type` VALUES ('47586a468f41410db4df1efcf6b5a388', 'HW08', '废矿物油与含矿物油废物', '1', 'system', '2016-06-23 16:52:04', 'system', '2016-06-23 16:52:04');
INSERT INTO `waste_type` VALUES ('535c26d26155478c9d58ba63fe7b4588', 'HW10', '多氯（溴） 联苯类 废物', '1', 'system', '2016-06-23 16:52:51', 'system', '2016-06-23 16:52:51');
INSERT INTO `waste_type` VALUES ('76a6e9550b35427daf7df27eef69de9d', 'HW11', '精（蒸） 馏残渣', '1', 'system', '2016-06-23 16:52:59', 'system', '2016-06-23 16:52:59');
INSERT INTO `waste_type` VALUES ('90b6a2dd15554117a94db175666a0f67', 'HW12', '染料、涂料废物', '1', 'system', '2016-06-23 16:53:20', 'system', '2016-06-23 16:53:20');
INSERT INTO `waste_type` VALUES ('225e7c86656041a0bfc78fa2ba958a87', 'HW13', '有机树脂类废物', '1', 'system', '2016-06-23 16:53:33', 'system', '2016-06-23 16:53:33');
INSERT INTO `waste_type` VALUES ('728a27b0d4ba4838b403093f62c46f6e', 'HW14', '新化学物 质废物', '1', 'system', '2016-06-23 16:53:42', 'system', '2016-06-23 16:53:42');
INSERT INTO `waste_type` VALUES ('e52b5600a1eb42659629526a44af9818', 'HW15', '爆炸性 废物', '1', 'system', '2016-06-23 16:54:02', 'system', '2016-06-23 16:54:02');
INSERT INTO `waste_type` VALUES ('1ea945430e9a4084afe7a9435d220eaa', 'HW16', '感光材料 废物', '1', '10000000000', '2016-08-10 14:58:09', '10000000000', '2016-08-10 14:58:09');
INSERT INTO `waste_type` VALUES ('296b0b9e961f4665b24f900781657d47', 'HW26', '含镉废物', '1', '1786833265281024', '2016-08-10 15:47:21', '1786833265281024', '2016-08-10 15:47:21');
INSERT INTO `waste_type` VALUES ('82fa236cdd3a4de5a36c904c04e03017', 'HW27', '含锑废物', '1', '1786833265281024', '2016-08-10 15:52:15', '1786833265281024', '2016-08-10 15:52:15');
INSERT INTO `waste_type` VALUES ('a2e87ec7f76f465ea357bf5aeb2fb6ac', 'HW28', '含碲废物', '1', '1786833265281024', '2016-08-10 15:54:40', '1786833265281024', '2016-08-10 15:54:40');
INSERT INTO `waste_type` VALUES ('ed16aa49d19a4850afdb2ac58a9142db', 'HW29', '含汞废物', '1', '1786833265281024', '2016-08-10 15:59:12', '1786833265281024', '2016-08-10 15:59:12');
INSERT INTO `waste_type` VALUES ('abca0d04df254a4b940f67427747ee19', 'HW30', '含铊废物', '1', '1786833265281024', '2016-08-10 16:28:54', '1786833265281024', '2016-08-10 16:28:54');
INSERT INTO `waste_type` VALUES ('15de68b97146446c9e10b94b22cd25df', 'HW31', '含铅废物', '1', '1786833265281024', '2016-08-10 16:34:58', '1786833265281024', '2016-08-10 16:34:58');
INSERT INTO `waste_type` VALUES ('751852941b294ad7bff5b93b399e4026', 'HW32', '无机氟化 物废物', '1', '1786833265281024', '2016-08-10 16:55:01', '1786833265281024', '2016-08-10 16:55:01');
INSERT INTO `waste_type` VALUES ('d56b9270eb7f4be1a6dba6cc73237d43', 'HW33', '无机氰化 物废物', '1', '1786833265281024', '2016-08-10 17:00:09', '1786833265281024', '2016-08-10 17:00:09');
INSERT INTO `waste_type` VALUES ('dde4afb14124489f86cc5a52f0e67a53', 'HW34', '废酸', '1', '1786833265281024', '2016-08-11 08:57:09', '1786833265281024', '2016-08-11 08:57:09');
INSERT INTO `waste_type` VALUES ('bc8ae1cf1ca04c1eb10d608516e30e69', 'HW35', '废碱', '1', '1786833265281024', '2016-08-11 09:09:51', '1786833265281024', '2016-08-11 09:09:51');
INSERT INTO `waste_type` VALUES ('29959a95d1704779a54463d34e33548e', 'HW36', '石棉废物', '1', '1786833265281024', '2016-08-11 09:18:00', '1786833265281024', '2016-08-11 09:18:00');
INSERT INTO `waste_type` VALUES ('558b9c5dd7bf41fcb5cf64aa12729c52', 'HW37', '有机磷化 合物废物', '1', '1786833265281024', '2016-08-11 09:29:05', '1786833265281024', '2016-08-11 09:29:05');
INSERT INTO `waste_type` VALUES ('8ef8531dc69249688d4605e7eb8e151f', 'HW38', '有机氰化物废物', '1', '1786833265281024', '2016-08-11 09:41:49', '1786833265281024', '2016-08-11 09:41:49');
INSERT INTO `waste_type` VALUES ('4cf86a793cad490bb2e03efa917fbc2a', 'HW39', '含酚废物', '1', '1786833265281024', '2016-08-11 09:45:44', '1786833265281024', '2016-08-11 09:45:44');
INSERT INTO `waste_type` VALUES ('85fe3b4db1ae42608fc3d0b8c3dd897a', 'HW40', '含醚废物', '1', '1786833265281024', '2016-08-11 09:47:04', '1786833265281024', '2016-08-11 09:47:04');
INSERT INTO `waste_type` VALUES ('f03587d8be404e3f9aaca675e177386d', 'HW45', '含有机卤化物废物', '1', '1786833265281024', '2016-08-11 09:48:07', '1786833265281024', '2016-08-11 09:48:07');
INSERT INTO `waste_type` VALUES ('d6b9c53d093142baaffc4ea8329815fe', 'HW46', '含镍废物', '1', '1786833265281024', '2016-08-11 09:52:24', '1786833265281024', '2016-08-11 09:52:24');
INSERT INTO `waste_type` VALUES ('a619e782e5534e15877f22c3c5388c9f', 'HW47', '含钡废物', '1', '1786833265281024', '2016-08-11 09:52:36', '1786833265281024', '2016-08-11 09:52:36');
INSERT INTO `waste_type` VALUES ('68fb2077a5e54be9bf818c7ff612e7e3', 'HW48', '有色金属 冶炼废物', '1', '1786833265281024', '2016-08-11 09:52:47', '1786833265281024', '2016-08-11 09:52:47');
INSERT INTO `waste_type` VALUES ('33453a42ef484c8fbb47ca6364ffb536', 'HW49', '其他废物', '1', '1786833265281024', '2016-08-11 09:53:06', '1786833265281024', '2016-08-11 09:53:06');
INSERT INTO `waste_type` VALUES ('a18013081b8b420a9f1a7d1aca0742ee', 'HW50', '废催化剂', '1', '1786833265281024', '2016-08-11 09:53:15', '1786833265281024', '2016-08-11 09:53:15');
INSERT INTO `waste_type` VALUES ('52f1fe16de0b44279583c90e537afeed', 'HW17', '表面处理 废物', '1', '1786843232307200', '2016-08-11 10:25:06', '1786843232307200', '2016-08-11 10:25:06');
INSERT INTO `waste_type` VALUES ('bf0b9327cde044389fa2c8c442c323f1', 'HW18', '焚烧处置 残渣', '1', '1786843232307200', '2016-08-11 10:25:46', '1786843232307200', '2016-08-11 10:25:46');
INSERT INTO `waste_type` VALUES ('4ba98819ff7c46edad682182c7a66b01', 'HW19', '含金属羰 基化合物 废物', '1', '1786843232307200', '2016-08-11 10:26:08', '1786843232307200', '2016-08-11 10:26:08');
INSERT INTO `waste_type` VALUES ('dac2873345c846b9a20464250d0a839f', 'HW20', '含铍废物', '1', '1786843232307200', '2016-08-11 10:26:20', '1786843232307200', '2016-08-11 10:26:20');
INSERT INTO `waste_type` VALUES ('86011ca679ed4c139300732dda383e2b', 'HW21', '含铬废物', '1', '1786843232307200', '2016-08-11 10:40:00', '1786843232307200', '2016-08-11 10:40:00');
INSERT INTO `waste_type` VALUES ('0fcc5fc677a34b028c711aaa590a9f47', 'HW22', '含铜废物', '1', '1786843232307200', '2016-08-11 10:40:19', '1786843232307200', '2016-08-11 10:40:19');
INSERT INTO `waste_type` VALUES ('83bd25156ec24a97bda3232710ac8929', 'HW23', '含锌废物', '1', '1786843232307200', '2016-08-11 10:40:42', '1786843232307200', '2016-08-11 10:40:42');
INSERT INTO `waste_type` VALUES ('904ae85f7a384c07ab38d73f21c8c19d', 'HW24', '含砷废物', '1', '1786843232307200', '2016-08-11 10:40:56', '1786843232307200', '2016-08-11 10:40:56');
INSERT INTO `waste_type` VALUES ('3a13947983434276b837eb15d349a1bc', 'HW25', '含硒废物', '1', '1786843232307200', '2016-08-11 10:41:08', '1786843232307200', '2016-08-11 10:41:08');
INSERT INTO `waste_type` VALUES ('ea8ae3bf58ad474e92e90cf2068ae744', 'HW09', '油/ 水、烃/ 水混合物 或乳化', '1', '1779778844067840', '2016-10-27 18:59:53', '1779778844067840', '2016-10-27 18:59:53');
