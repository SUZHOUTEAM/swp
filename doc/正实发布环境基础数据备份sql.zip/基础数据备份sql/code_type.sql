/*
Navicat MySQL Data Transfer

Source Server         : swp
Source Server Version : 50518
Source Host           : rm-bp1d2e125t78314n3o.mysql.rds.aliyuncs.com:3306
Source Database       : yifei_db

Target Server Type    : MYSQL
Target Server Version : 50518
File Encoding         : 65001

Date: 2017-02-22 14:57:18
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for code_type
-- ----------------------------
DROP TABLE IF EXISTS `code_type`;
CREATE TABLE `code_type` (
  `id` varchar(32) NOT NULL,
  `type_code` varchar(20) NOT NULL,
  `type_name` varchar(50) NOT NULL,
  `splice` varchar(1) NOT NULL,
  `status` varchar(1) NOT NULL,
  `create_by` varchar(50) NOT NULL,
  `create_time` datetime NOT NULL,
  `edit_by` varchar(50) NOT NULL,
  `edit_time` datetime NOT NULL,
  PRIMARY KEY (`id`,`type_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of code_type
-- ----------------------------
INSERT INTO `code_type` VALUES ('0912bda92e83434f83151f1a9f32fd87', 'FOLLOW_TYPE', '易废圈-被关注者类型', '1', '1', '1779881942894592', '2016-10-26 15:30:43', '1779881942894592', '2016-10-26 15:30:43');
INSERT INTO `code_type` VALUES ('107cd81bad144296b7368791e0217b02', 'LIC_PERMIT', '许可证危废许可方式', '1', '1', 'system', '2016-06-23 13:13:02', 'system', '2016-07-01 12:02:41');
INSERT INTO `code_type` VALUES ('17c165d64eb345348bc9ce7776bfd04c', 'DISPLAN_ATYPE', '委托处理计划-应答信息状态', '1', '1', 'system', '2016-07-12 15:50:32', '1779881942894592', '2016-10-26 15:35:05');
INSERT INTO `code_type` VALUES ('336e2323413c452680a091de0c10514d', 'Disposal_Enter', '处置企业', '1', '1', 'system', '2016-07-13 15:24:12', 'system', '2016-07-13 15:24:12');
INSERT INTO `code_type` VALUES ('3a3ce9de2ce64fb1b3c3adb3a2c7e03b', 'LIC_CALC_TYPE', '许可证危废许可方式', '1', '1', '1779881942894592', '2016-10-27 14:59:38', '1779881942894592', '2016-10-27 14:59:38');
INSERT INTO `code_type` VALUES ('3f696bab2e9944acb7209bbaac55bd13', 'USER_EVENT_STATUS', '用户/企业事件状态', '1', '1', 'SYSTEM', '2016-08-03 13:56:38', 'SYSTEM', '2016-08-03 13:56:38');
INSERT INTO `code_type` VALUES ('46a384999fc747daba18ff31eb38c923', 'ENTERPRISE_TYPE', '企业类型', '1', '1', '1776613402331136', '2016-08-03 15:00:08', '1776613402331136', '2016-08-03 15:00:08');
INSERT INTO `code_type` VALUES ('5227f295986e435696b9e47f6a5798d6', 'DISCAPACITY_ATYPE', '处置能力-应答信息状态', '1', '1', '1779881942894592', '2016-10-26 15:33:30', '1779881942894592', '2016-10-26 15:33:30');
INSERT INTO `code_type` VALUES ('6ca28589888b4c35b005233faf6bce12', 'WASTE_SOURCE', '危废产生源', '1', '1', 'system', '2016-06-23 13:12:09', 'system', '2016-06-23 13:12:09');
INSERT INTO `code_type` VALUES ('7fed1baee44640aa813a7d937467a324', 'LIC_AUDIT', '许可证审核状态', '1', '1', 'system', '2016-06-29 14:08:23', 'system', '2016-06-29 14:08:23');
INSERT INTO `code_type` VALUES ('86b62b72817d474ab30fa37862c7958d', 'Waste_Ent', '产废企业', '1', '1', 'system', '2016-07-13 15:23:10', 'system', '2016-07-13 15:23:10');
INSERT INTO `code_type` VALUES ('902391953e8e4f959a21f339a01f565b', 'PRODUCT_TYPE', '产废类型', '0', '1', 'system', '2016-06-23 13:08:59', 'system', '2016-06-23 13:08:59');
INSERT INTO `code_type` VALUES ('9d3359058fae4da797c5732aa1a1b169', 'UNIT_TYPE', '计量单位', '1', '1', 'system', '2016-06-23 13:11:24', 'system', '2016-06-23 13:11:24');
INSERT INTO `code_type` VALUES ('a8733348cdd84950937a6848221a9a02', 'DISPLAN_RTYPE', '委托处理计划-发布信息状态', '1', '1', 'system', '2016-07-12 15:49:59', 'system', '2016-07-12 15:49:59');
INSERT INTO `code_type` VALUES ('b06f5b70c0784c9e9efa0fbfc7e5a440', 'VEHICLE_TYPE', '运输工具类型', '0', '1', 'system', '2016-06-23 13:10:21', 'system', '2016-06-23 13:10:21');
INSERT INTO `code_type` VALUES ('ba067d6fef72481a9b1bccf1e5f5631c', 'USER_EVENT_TYPE', '用户/企业事件类型', '1', '1', 'SYSTEM', '2016-08-03 13:55:50', '1779881942894592', '2016-10-26 15:29:00');
INSERT INTO `code_type` VALUES ('c95fb4ad8d204c6c87830bcaaa774540', 'NOTICE_TYPE', '易废圈-通知类型', '1', '1', '1779881942894592', '2016-10-26 15:32:10', '1779881942894592', '2016-10-26 15:32:10');
INSERT INTO `code_type` VALUES ('d4255f1bd8114633a76e5986c3301b86', 'RECEIVER_TYPE', '易废圈-被通知者类型', '1', '1', '1779881942894592', '2016-10-26 15:31:25', '1779881942894592', '2016-10-26 15:31:25');
INSERT INTO `code_type` VALUES ('d9cd1b5b91f94da0b46c921212bab91d', 'LIC_VALID', '许可证有效状态', '1', '1', 'system', '2016-06-29 14:10:31', 'system', '2016-06-29 14:10:31');
INSERT INTO `code_type` VALUES ('de5285a601fa48b29d2bdebc7816b0bf', 'DISCAPACITY_RTYPE', '处置能力-发布信息状态', '1', '1', '1779881942894592', '2016-10-26 15:32:49', '1779881942894592', '2016-10-26 15:32:49');
INSERT INTO `code_type` VALUES ('e15b02a1527442f7a80c73b766f119fd', 'LIC_MODE', '核准经营方式', '1', '1', 'system', '2016-06-28 15:39:13', 'system', '2016-06-28 15:39:13');
INSERT INTO `code_type` VALUES ('e15b02a9213329f7a80c73b766f119fd', 'QUOTE_TYPE', '委托处理计划-报价方式', '1', '1', 'system', '2016-07-11 14:55:49', 'system', '2016-07-18 14:55:56');
INSERT INTO `code_type` VALUES ('f5a80dcb6f5d47c482a3c10f3bd979c8', 'WASTE_FLAG', '危险废物种类', '1', '1', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
INSERT INTO `code_type` VALUES ('f69431205f354dd69eca8ccc4ffa4618', 'DISPOSE_TYPE', '危废处置方式', '1', '1', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_type` VALUES ('fb6802a399ea4167b3874dad1a5fdc1c', 'WASTE_PATTERN', '废物形态', '1', '1', 'system', '2016-06-23 13:09:38', 'SYSTEM', '2016-07-27 18:25:54');
INSERT INTO `code_type` VALUES ('fbed0c66ae334625aec979dbdc7c33a6', 'WASTE_FEATURES', '危废特性', '1', '1', 'system', '2016-06-23 13:07:20', 'SYSTEM', '2016-07-27 18:25:19');
