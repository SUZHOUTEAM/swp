/*
Navicat MySQL Data Transfer

Source Server         : swp
Source Server Version : 50518
Source Host           : rm-bp1d2e125t78314n3o.mysql.rds.aliyuncs.com:3306
Source Database       : yifei_db

Target Server Type    : MYSQL
Target Server Version : 50518
File Encoding         : 65001

Date: 2017-02-22 14:57:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for code_value
-- ----------------------------
DROP TABLE IF EXISTS `code_value`;
CREATE TABLE `code_value` (
  `id` varchar(32) NOT NULL,
  `type_id` varchar(32) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `value` varchar(50) NOT NULL,
  `create_by` varchar(50) NOT NULL,
  `create_time` datetime NOT NULL,
  `edit_by` varchar(50) NOT NULL,
  `edit_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of code_value
-- ----------------------------
INSERT INTO `code_value` VALUES ('0075fcd8101642728a183af3cc53f889', '6ca28589888b4c35b005233faf6bce12', 'G1', '生产工艺过程产生', 'system', '2016-06-23 13:12:09', 'system', '2016-06-23 13:12:09');
INSERT INTO `code_value` VALUES ('0114c3a72d1346bcbfac8b8c3a2218b8', '7fed1baee44640aa813a7d937467a324', 'SUBMIT', '待审核', 'system', '2016-06-29 14:08:23', 'system', '2016-06-29 14:08:23');
INSERT INTO `code_value` VALUES ('01d68faff7f343c29f471c75098b73b8', 'e15b02a1527442f7a80c73b766f119fd', 'COLLECTION', '危险废物收集经营', 'system', '2016-06-28 15:39:13', 'system', '2016-06-28 15:39:13');
INSERT INTO `code_value` VALUES ('01de1603e159498d83b041a71ae17136', 'fb6802a399ea4167b3874dad1a5fdc1c', 'SS', '半固体', 'system', '2016-06-23 13:09:38', 'system', '2016-06-23 13:09:38');
INSERT INTO `code_value` VALUES ('1270028bfac8428381e4ccd6faa2b41d', 'f69431205f354dd69eca8ccc4ffa4618', 'R15', '其他', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('1681065da0b0412c83036aabe249dc5a', '902391953e8e4f959a21f339a01f565b', '', '非生产性产废', 'system', '2016-06-23 13:08:59', 'system', '2016-06-23 13:08:59');
INSERT INTO `code_value` VALUES ('1855475744374d169a2268c43ea2f98e', '46a384999fc747daba18ff31eb38c923', 'RECYCLING', '综合利用企业', '1776613402331136', '2016-08-03 15:00:08', '1776613402331136', '2016-08-03 15:00:08');
INSERT INTO `code_value` VALUES ('1afbcac4931c4323b4855b11c59c1714', 'f69431205f354dd69eca8ccc4ffa4618', 'G21', '干法解毒', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('20c8ccb1fcaa44748855d95023f5732c', '902391953e8e4f959a21f339a01f565b', '', '次生危废', 'system', '2016-06-23 13:08:59', 'system', '2016-06-23 13:08:59');
INSERT INTO `code_value` VALUES ('2161a1e57cd049d29366fb6adcb21344', 'f69431205f354dd69eca8ccc4ffa4618', 'R9', '废油再提炼或其他废油的再利用', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('2473ae71c5814b8991f5e6f5ecd9105a', 'd9cd1b5b91f94da0b46c921212bab91d', 'VALID', '有效', 'system', '2016-06-29 14:10:31', 'system', '2016-06-29 14:10:31');
INSERT INTO `code_value` VALUES ('269abf58c926458bb3ffbe90e507265b', 'c95fb4ad8d204c6c87830bcaaa774540', 'PURCHASE_STATUS', '购买动态', '1779881942894592', '2016-10-26 15:32:10', '1779881942894592', '2016-10-26 15:32:10');
INSERT INTO `code_value` VALUES ('286e4419b4854e22942106dfc61be7af', '6ca28589888b4c35b005233faf6bce12', 'G2', '事故（如泄漏）产生。包括溢出的污染物及清洁被污染设备过程中产生的废物等', 'system', '2016-06-23 13:12:09', 'system', '2016-06-23 13:12:09');
INSERT INTO `code_value` VALUES ('29a0d7329e2d4d8dbb4e1fcc41c08d77', 'f69431205f354dd69eca8ccc4ffa4618', 'R6', '再生酸或碱', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('2cbaf4c56192417c8d0957cbc6ba3cc9', '7fed1baee44640aa813a7d937467a324', 'CREATE', '企业创建', 'system', '2016-06-29 14:08:23', 'system', '2016-06-29 14:08:23');
INSERT INTO `code_value` VALUES ('314386526bf749c599185e3adebfafc9', 'f5a80dcb6f5d47c482a3c10f3bd979c8', 'Irritant', '刺激性', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
INSERT INTO `code_value` VALUES ('3287479cc526466885749fb0b6da1c9a', '7fed1baee44640aa813a7d937467a324', 'PASS', '审核通过', 'system', '2016-06-29 14:08:23', 'system', '2016-06-29 14:08:23');
INSERT INTO `code_value` VALUES ('32f00db1b97847769c2eaf1cb3edf273', 'fbed0c66ae334625aec979dbdc7c33a6', 'R', '反应性', 'system', '2016-06-23 13:07:20', 'system', '2016-06-23 13:07:20');
INSERT INTO `code_value` VALUES ('33fb9c9bd734452d9b980c09b9beb68b', '3a3ce9de2ce64fb1b3c3adb3a2c7e03b', 'CALC_EXCEPT', '不包含指定八位码', '1779881942894592', '2016-10-27 14:59:38', '1779881942894592', '2016-10-27 14:59:38');
INSERT INTO `code_value` VALUES ('3577f66c51c544dfbbef829d7140f49f', '6ca28589888b4c35b005233faf6bce12', 'G4', '其他', 'system', '2016-06-23 13:12:09', 'system', '2016-06-23 13:12:09');
INSERT INTO `code_value` VALUES ('3695a036f9d84495be22ea303f3fefff', 'f69431205f354dd69eca8ccc4ffa4618', 'R4', '再循环/再利用金属和金属化合物', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('3deefe62a68048b4a3eb1e8d83f15b5c', '9d3359058fae4da797c5732aa1a1b169', 'C', '只', 'system', '2016-06-23 13:11:24', 'system', '2016-06-23 13:11:24');
INSERT INTO `code_value` VALUES ('3e07490ffa0a42d1aae8101b7169f29f', 'b06f5b70c0784c9e9efa0fbfc7e5a440', '', '飞机', 'system', '2016-06-23 13:10:21', 'system', '2016-06-23 13:10:21');
INSERT INTO `code_value` VALUES ('3eb95c3908004b10a2bee1723c8b777b', '17c165d64eb345348bc9ce7776bfd04c', 'UNSUBMIT', '未提交', '1779881942894592', '2016-10-26 15:28:09', '1779881942894592', '2016-10-26 15:28:09');
INSERT INTO `code_value` VALUES ('4144696047ef45aa80408e273a41bc07', '46a384999fc747daba18ff31eb38c923', 'DISPOSITION', '处置企业', '1776613402331136', '2016-08-03 15:00:08', '1776613402331136', '2016-08-03 15:00:08');
INSERT INTO `code_value` VALUES ('41b02bee65874fc88eb0d8fe09dd65f4', 'fb6802a399ea4167b3874dad1a5fdc1c', 'G', '气态', 'SYSTEM', '2016-07-27 18:25:54', 'system', '2016-06-23 13:09:38');
INSERT INTO `code_value` VALUES ('4252f3bf5fa14f69be3e7783865849f3', 'f69431205f354dd69eca8ccc4ffa4618', 'G23', '烧结炼铁', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('43080d2a38a64767ae60de9de6cabd56', '3f696bab2e9944acb7209bbaac55bd13', 'REVERSED', '申请已撤回', 'SYSTEM', '2016-08-03 13:56:38', 'SYSTEM', '2016-08-03 13:56:38');
INSERT INTO `code_value` VALUES ('45c424f2a39b4a23885842870c98fdc9', 'f69431205f354dd69eca8ccc4ffa4618', 'D10', '焚烧', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('47ad2124a16f4c31a3906a6df676ee81', 'fb6802a399ea4167b3874dad1a5fdc1c', 'S', '固态', 'system', '2016-06-23 13:09:38', 'system', '2016-06-23 13:09:38');
INSERT INTO `code_value` VALUES ('48f60673a53d4b758b9d240b8dbf66de', '17c165d64eb345348bc9ce7776bfd04c', 'ACCEPT', '已确认', 'system', '2016-07-12 15:50:32', 'system', '2016-07-12 15:50:32');
INSERT INTO `code_value` VALUES ('5307f5c36e1642fea7d95a668b0d3db7', '3a3ce9de2ce64fb1b3c3adb3a2c7e03b', 'CALC_ALL', '包含所有八位码', '1779881942894592', '2016-10-27 14:59:38', '1779881942894592', '2016-10-27 14:59:38');
INSERT INTO `code_value` VALUES ('53c9ba58b91f49628b1466c465bf9bdb', '5227f295986e435696b9e47f6a5798d6', 'ACCEPT', '已确认', '1779881942894592', '2016-10-26 15:33:30', '1779881942894592', '2016-10-26 15:33:30');
INSERT INTO `code_value` VALUES ('540b14d498d0427db029727e2ae4b24c', '107cd81bad144296b7368791e0217b02', 'CALC_ALL', '包含全部八位码', 'system', '2016-06-23 13:13:02', 'system', '2016-07-01 12:02:41');
INSERT INTO `code_value` VALUES ('55346cbb47d64db28767a034f62ce654', 'ba067d6fef72481a9b1bccf1e5f5631c', 'JOIN', '加入企业', 'SYSTEM', '2016-08-03 13:55:51', 'SYSTEM', '2016-08-03 13:55:51');
INSERT INTO `code_value` VALUES ('564faae2ce4144e8963652214e417999', 'f69431205f354dd69eca8ccc4ffa4618', 'R3', '再循环/再利用不是用作溶剂的有机物', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('567b33278a364b7c90aea9c4fb0b13f9', 'f69431205f354dd69eca8ccc4ffa4618', 'D9', '埋或焚烧前的预处理', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('5c47d7df86134f5c822eb170f98854c4', 'c95fb4ad8d204c6c87830bcaaa774540', 'SYS_TYPE', '系统消息', '1779881942894592', '2016-10-26 15:32:10', '1779881942894592', '2016-10-26 15:32:10');
INSERT INTO `code_value` VALUES ('5e92ff67491b4c42838a18eac652c61f', '3f696bab2e9944acb7209bbaac55bd13', 'SUBMIT', '申请已提交', 'SYSTEM', '2016-08-03 13:56:38', 'SYSTEM', '2016-08-03 13:56:38');
INSERT INTO `code_value` VALUES ('6001d8b04a814418b3a41075f0b3f6f5', '17c165d64eb345348bc9ce7776bfd04c', 'SUBMIT', '已提交', 'system', '2016-07-12 15:50:32', 'system', '2016-07-12 15:50:32');
INSERT INTO `code_value` VALUES ('621ebdb138e44772ae873bedd37ffcc9', '46a384999fc747daba18ff31eb38c923', 'PRODUCTION', '产废企业', '1776613402331136', '2016-08-03 15:00:08', '1776613402331136', '2016-08-03 15:00:08');
INSERT INTO `code_value` VALUES ('641d5569dcce46e582ec37e5bd634296', 'de5285a601fa48b29d2bdebc7816b0bf', 'CANCEL', '已中止', '1779881942894592', '2016-10-26 15:32:49', '1779881942894592', '2016-10-26 15:32:49');
INSERT INTO `code_value` VALUES ('64d21556898843d88369c2f7cbd31510', 'c95fb4ad8d204c6c87830bcaaa774540', 'NEW_ORDER', '新的订单', '1779881942894592', '2016-10-26 15:32:10', '1779881942894592', '2016-10-26 15:32:10');
INSERT INTO `code_value` VALUES ('64f1807a1b634cc3b9ee7a6bde94638f', 'f69431205f354dd69eca8ccc4ffa4618', 'R2', '溶剂回收/再生（如蒸馏、萃取等）', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('6a90e74176674ac58146f88513175743', 'f69431205f354dd69eca8ccc4ffa4618', 'D1', '填埋', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('6e6fe86f30fe479a969a1e5f874f1ac7', 'f5a80dcb6f5d47c482a3c10f3bd979c8', 'Oxidizing', '助燃', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
INSERT INTO `code_value` VALUES ('6fb6489be3c34880b207c509032fd042', '7fed1baee44640aa813a7d937467a324', 'REFUSED', '审核退回', 'system', '2016-06-29 14:08:23', 'system', '2016-06-29 14:08:23');
INSERT INTO `code_value` VALUES ('74834ad874aa4a3f921bc8b5fc07f132', '46a384999fc747daba18ff31eb38c923', 'IDENTIFICATION', '鉴定机构', '1776613402331136', '2016-08-03 15:00:08', '1776613402331136', '2016-08-03 15:00:08');
INSERT INTO `code_value` VALUES ('7a3804425dd24849a737a7a9f333d892', 'c95fb4ad8d204c6c87830bcaaa774540', 'NEW_RESOURCELIST', '新的资源单', '1779881942894592', '2016-10-26 15:32:10', '1779881942894592', '2016-10-26 15:32:10');
INSERT INTO `code_value` VALUES ('81bf990cab9842f2ad8e41ddf631704d', 'f69431205f354dd69eca8ccc4ffa4618', 'Y10', '医疗废物焚烧', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('8213d7ac606245ec8f6ab1ad1acf4bc7', '17c165d64eb345348bc9ce7776bfd04c', 'REFUSED', '已谢绝', '1779881942894592', '2016-10-26 15:35:05', '1779881942894592', '2016-10-26 15:35:05');
INSERT INTO `code_value` VALUES ('8383d240fd764b4d9f417b1187aaf136', 'e15b02a1527442f7a80c73b766f119fd', 'INCLUDEALL', '危险废物收集、贮存、处置综合经营', 'system', '2016-06-28 15:39:13', 'system', '2016-06-28 15:39:13');
INSERT INTO `code_value` VALUES ('84438c9476a840bc9953bd923aa30f48', 'f69431205f354dd69eca8ccc4ffa4618', 'Y11', '医疗废物高温蒸汽处理', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('86ddf11b6ddb4d9e9545e6acab63c3f1', 'f5a80dcb6f5d47c482a3c10f3bd979c8', 'Explosive', '爆炸性', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
INSERT INTO `code_value` VALUES ('8846edbe18664b88b5a9289bbbb3b795', 'f69431205f354dd69eca8ccc4ffa4618', 'C1', '水泥窑共处置', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('8acefa7c229942f18c37f4972595266a', 'f69431205f354dd69eca8ccc4ffa4618', 'Y13', '医疗废物微波消毒处理', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('8e5f6f0c0f084882a1f7c0a556efd9b2', 'f5a80dcb6f5d47c482a3c10f3bd979c8', 'Asbestos', '石棉', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
INSERT INTO `code_value` VALUES ('8eac838e91c647e9a5127dcb89401d18', 'f69431205f354dd69eca8ccc4ffa4618', 'R8', '回收催化剂组分', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('96451534ee724a75941bb4c8ffdd5860', '5227f295986e435696b9e47f6a5798d6', 'SUBMIT', '已提交', '1779881942894592', '2016-10-26 15:33:30', '1779881942894592', '2016-10-26 15:33:30');
INSERT INTO `code_value` VALUES ('976d18cc9b3740ceb3d84418da41c981', 'f5a80dcb6f5d47c482a3c10f3bd979c8', 'Flammable', '易燃', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
INSERT INTO `code_value` VALUES ('99093bda0f6f4154b2b828fe2fc8ccf0', 'f69431205f354dd69eca8ccc4ffa4618', 'G22', '湿法解毒', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('996ecc51316847a58d63f767c3c3bfaf', 'fbed0c66ae334625aec979dbdc7c33a6', 'I', '易燃性', 'system', '2016-06-23 13:07:20', 'system', '2016-06-23 13:07:20');
INSERT INTO `code_value` VALUES ('9c2e43a4d0bf42a8be82f7df8a35c1f6', '0912bda92e83434f83151f1a9f32fd87', 'SINGLE', '个人用户', '1779881942894592', '2016-10-26 15:30:43', '1779881942894592', '2016-10-26 15:30:43');
INSERT INTO `code_value` VALUES ('9e19ae70240f4a52a8dbd41b9f293663', 'f5a80dcb6f5d47c482a3c10f3bd979c8', 'Toxic', '有毒', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
INSERT INTO `code_value` VALUES ('9fb636feac8c4638b94944315fddbf18', '86b62b72817d474ab30fa37862c7958d', 'W001', '委托处理', 'system', '2016-07-13 15:23:10', 'system', '2016-07-13 15:23:10');
INSERT INTO `code_value` VALUES ('a06f378999df4deeb41e618ceed998f4', 'fbed0c66ae334625aec979dbdc7c33a6', 'T', '毒性', 'system', '2016-06-23 13:07:20', 'system', '2016-06-23 13:07:20');
INSERT INTO `code_value` VALUES ('a0fd57f9fb7449a8b65b5cf20bd38d31', 'f69431205f354dd69eca8ccc4ffa4618', 'Y12', '医疗废物化学消毒处理', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('a330cd3e67c64d3f897bd06d2d753c21', 'f69431205f354dd69eca8ccc4ffa4618', 'D16', '其他', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('a6cc7de0387c466a9ef0456a2425fbeb', '5227f295986e435696b9e47f6a5798d6', 'COLSED', '已关闭', '1779881942894592', '2016-10-26 15:33:30', '1779881942894592', '2016-10-26 15:33:30');
INSERT INTO `code_value` VALUES ('a91acdeb7b374e3ca50be0308430a9ec', 'a8733348cdd84950937a6848221a9a02', 'RELEASE', '已发布', 'system', '2016-07-12 15:49:59', 'system', '2016-07-12 15:49:59');
INSERT INTO `code_value` VALUES ('aa5ab5a48fa546afbed00f56ba4a39a5', 'f69431205f354dd69eca8ccc4ffa4618', 'Y16', '医疗废物其他处置方式', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('ad12c0df74564b85936967c97acc4a97', '107cd81bad144296b7368791e0217b02', 'CALC_INCLUDE', '包含以下指定八位码', 'system', '2016-06-23 13:13:02', 'system', '2016-07-01 12:02:41');
INSERT INTO `code_value` VALUES ('b2e442278ea84a089494e03dd95b66cf', 'b06f5b70c0784c9e9efa0fbfc7e5a440', '', '船舶', 'system', '2016-06-23 13:10:21', 'system', '2016-06-23 13:10:21');
INSERT INTO `code_value` VALUES ('b32b678d4a0e49218c575c1e96b1b933', 'fbed0c66ae334625aec979dbdc7c33a6', 'In', '感染性', 'system', '2016-06-23 13:07:20', 'system', '2016-06-23 13:07:20');
INSERT INTO `code_value` VALUES ('b35b3c754a574647b20a73abc0ca4a44', 'ba067d6fef72481a9b1bccf1e5f5631c', 'QUIT', '退出企业', 'SYSTEM', '2016-08-03 13:55:51', 'SYSTEM', '2016-08-03 13:55:51');
INSERT INTO `code_value` VALUES ('b3cbc24db8114ad0a5be7761c8007f66', 'f69431205f354dd69eca8ccc4ffa4618', 'R5', '再循环/再利用其他无机物', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('b514d0e08a6c448096aaa74e88de3f11', 'e15b02a9213329f7a80c73b766f119fd', 'TOTAL_QUOTE', '整体报价', 'system', '2016-07-04 14:56:42', 'system', '2016-07-05 14:56:48');
INSERT INTO `code_value` VALUES ('b6b8232a03f546a689107f75db7c4c5c', 'f69431205f354dd69eca8ccc4ffa4618', 'G24', '生产水泥', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('b8425fe1053244958f69f2c743294b5b', '9d3359058fae4da797c5732aa1a1b169', 'T', '吨', 'system', '2016-06-23 13:11:24', 'system', '2016-06-23 13:11:24');
INSERT INTO `code_value` VALUES ('bbfa79769b434b979098aded2e886a31', 'fbed0c66ae334625aec979dbdc7c33a6', 'C', '腐蚀性', 'system', '2016-06-23 13:07:20', 'system', '2016-06-23 13:07:20');
INSERT INTO `code_value` VALUES ('bdbd3c8ae0f04c28b0d1f0c505517718', '46a384999fc747daba18ff31eb38c923', 'TRANSPORTATION', '运输企业', '1776613402331136', '2016-08-03 15:00:08', '1776613402331136', '2016-08-03 15:00:08');
INSERT INTO `code_value` VALUES ('c00011005b7647ed9a3e311861e6f5b6', '336e2323413c452680a091de0c10514d', 'D001', '转移计划', 'system', '2016-07-13 15:24:12', 'system', '2016-07-13 15:24:12');
INSERT INTO `code_value` VALUES ('c125b755f5fd48cdb13ec50efc183cbd', '3f696bab2e9944acb7209bbaac55bd13', 'PASS', '申请通过', 'SYSTEM', '2016-08-03 13:56:38', 'SYSTEM', '2016-08-03 13:56:38');
INSERT INTO `code_value` VALUES ('c57077ca179f4c39beb535a54ca9de97', 'de5285a601fa48b29d2bdebc7816b0bf', 'RELEASE', '已发布', '1779881942894592', '2016-10-26 15:32:49', '1779881942894592', '2016-10-26 15:32:49');
INSERT INTO `code_value` VALUES ('c7519bdbe5bb48fa87d7f72c159da974', 'a8733348cdd84950937a6848221a9a02', 'ACCEPT', '已确认', 'system', '2016-07-12 15:49:59', 'system', '2016-07-12 15:49:59');
INSERT INTO `code_value` VALUES ('c7e8a72f408b4fde8dec7afae32c77a1', 'e15b02a9213329f7a80c73b766f119fd', 'DETAIL_QUOTE', '明细报价', 'system', '2016-07-05 14:57:27', 'system', '2016-07-06 14:57:30');
INSERT INTO `code_value` VALUES ('cb932aaca85c48909bde04a5da26b668', '3f696bab2e9944acb7209bbaac55bd13', 'REFUSED', '申请未通过', 'SYSTEM', '2016-08-03 13:56:38', 'SYSTEM', '2016-08-03 13:56:38');
INSERT INTO `code_value` VALUES ('d118d4b5bdba44fea37c428654b8b493', 'f69431205f354dd69eca8ccc4ffa4618', 'R7', '回收污染减除剂的组分', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('d287067514ea4039be91b0a982afdb87', '3a3ce9de2ce64fb1b3c3adb3a2c7e03b', 'CALC_INCLUDE', '包含指定八位码', '1779881942894592', '2016-10-27 14:59:38', '1779881942894592', '2016-10-27 14:59:38');
INSERT INTO `code_value` VALUES ('d401426e65a04b86bf2908ac5aa374e8', 'f69431205f354dd69eca8ccc4ffa4618', 'C3', '清洗（包装容器）', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('d5994053ee3d42f3805644ac1aafcfd8', 'd4255f1bd8114633a76e5986c3301b86', 'SINGLE', '个人用户', '1779881942894592', '2016-10-26 15:31:25', '1779881942894592', '2016-10-26 15:31:25');
INSERT INTO `code_value` VALUES ('d616c2560712466c936e4f4f244493b9', 'ba067d6fef72481a9b1bccf1e5f5631c', 'CREATE', '创建企业', 'SYSTEM', '2016-08-03 13:55:51', 'SYSTEM', '2016-08-03 13:55:51');
INSERT INTO `code_value` VALUES ('d8e2fc69bd1e43c18ae197d2d18ac9c2', 'd9cd1b5b91f94da0b46c921212bab91d', 'INVALID', '未生效', 'system', '2016-06-29 14:10:31', 'system', '2016-06-29 14:10:31');
INSERT INTO `code_value` VALUES ('e1ec1bfdc7ca4712af2bdd1e8a8dfd0d', 'f69431205f354dd69eca8ccc4ffa4618', 'C2', '生产建筑材料', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('e2e511b4119549d5857963fa2f9811bb', 'f5a80dcb6f5d47c482a3c10f3bd979c8', 'Corrosive', '腐蚀性', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
INSERT INTO `code_value` VALUES ('e31e9cd8bda7489d851c0516e5cc95bc', 'f69431205f354dd69eca8ccc4ffa4618', 'R1', '作为燃料（直接燃烧除外）或以其他方式产生能量', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('e6a45e1e6ac04e5b9f892c4bbcb61dfc', '902391953e8e4f959a21f339a01f565b', '', '生产性产废', 'system', '2016-06-23 13:08:59', 'system', '2016-06-23 13:08:59');
INSERT INTO `code_value` VALUES ('e70ad9d3bb354acba3af392dfb5a4379', 'd4255f1bd8114633a76e5986c3301b86', 'ORGANIZED', '企业用户', '1779881942894592', '2016-10-26 15:31:25', '1779881942894592', '2016-10-26 15:31:25');
INSERT INTO `code_value` VALUES ('e9c459ca46464e558847eaa4abb205da', '107cd81bad144296b7368791e0217b02', 'CALC_EXCEPT', '排除以下指定八位码', 'system', '2016-06-23 13:13:02', 'system', '2016-07-01 12:02:41');
INSERT INTO `code_value` VALUES ('eb14fdbf061d41e7b20be307957e780b', 'f69431205f354dd69eca8ccc4ffa4618', 'G29', '其他', 'system', '2016-06-23 14:47:21', 'system', '2016-06-23 14:47:21');
INSERT INTO `code_value` VALUES ('ecdc3b732bda4641a66cbff918f88f02', 'ba067d6fef72481a9b1bccf1e5f5631c', 'UPDATE', '更新企业', '1779881942894592', '2016-10-26 15:29:00', '1779881942894592', '2016-10-26 15:29:00');
INSERT INTO `code_value` VALUES ('eec2bca9311e4237b2074f1e12265e60', 'd9cd1b5b91f94da0b46c921212bab91d', 'OVERDUE', '过期', 'system', '2016-06-29 14:10:31', 'system', '2016-06-29 14:10:31');
INSERT INTO `code_value` VALUES ('ef435a111f7c4841a4475822d6cff4e3', '0912bda92e83434f83151f1a9f32fd87', 'ORGANIZED', '企业用户', '1779881942894592', '2016-10-26 15:30:43', '1779881942894592', '2016-10-26 15:30:43');
INSERT INTO `code_value` VALUES ('f7d7a64f43674ac6b071fddd9c9e9763', 'fb6802a399ea4167b3874dad1a5fdc1c', 'L', '液态', 'system', '2016-06-23 13:09:38', 'system', '2016-06-23 13:09:38');
INSERT INTO `code_value` VALUES ('f8529e2dff034979b3a8d935ca4892e5', '6ca28589888b4c35b005233faf6bce12', 'G3', '设备检修、清库等过程产生', 'system', '2016-06-23 13:12:09', 'system', '2016-06-23 13:12:09');
INSERT INTO `code_value` VALUES ('fb73d25a484343a091bc7bc92f56674a', 'b06f5b70c0784c9e9efa0fbfc7e5a440', '', '汽车', 'system', '2016-06-23 13:10:21', 'system', '2016-06-23 13:10:21');
INSERT INTO `code_value` VALUES ('fd57895838a24d03be37ae28487b51b9', '17c165d64eb345348bc9ce7776bfd04c', 'COLSED', '已关闭', '1779881942894592', '2016-10-26 15:28:09', '1779881942894592', '2016-10-26 15:28:09');
INSERT INTO `code_value` VALUES ('ffb642d62aaa47e49cc187ec33db35d6', 'f5a80dcb6f5d47c482a3c10f3bd979c8', 'Harmful', '有害', 'system', '2016-06-23 13:08:33', 'system', '2016-06-23 13:08:33');
